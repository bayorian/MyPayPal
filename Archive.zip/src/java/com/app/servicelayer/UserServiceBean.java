/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalUser;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.ClientErrorException;

/**
 *
 * @author p-computers
 */
@Stateless
@DeclareRoles({"User", "Admin"})
public class UserServiceBean implements UserServiceBeanLocal {

    @PersistenceContext
    EntityManager entityManager;    

    private static final Logger LOG = Logger.getLogger("UserServiceBean");

    @Override
    @PermitAll
    public MyPayPalUser getUser(String email) {
        try {
            MyPayPalUser myPayPalUser = entityManager.find(MyPayPalUser.class, email);
            return myPayPalUser;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

    @Override
    @PermitAll
    public MyPayPalUser createUser(String email, String password, String currency, String name, String userType) {
        try {
            MyPayPalUser myPayPalUser = new MyPayPalUser(name, password, email, currency, userType);
            entityManager.persist(myPayPalUser);            
            return myPayPalUser;
        } catch (ConstraintViolationException e) {
            LOG.log(Level.SEVERE, "Exception: ");
            e.getConstraintViolations().forEach(err -> LOG.log(Level.SEVERE, err.toString()));
            return null;
        } catch (ClientErrorException e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public boolean updateUser(MyPayPalUser myPayPalUser) {
        try {
            entityManager.merge(myPayPalUser);
            return true;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return false;
        }
    }

    @Override
    @RolesAllowed({"Admin"})
    public boolean setUserType(String email, String userType) {
        try {
             MyPayPalUser myPayPalUser = getUser(email);
             myPayPalUser.setUserType(userType);
             updateUser(myPayPalUser);
            return true;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return false;
        }
    }    
    
    @Override
    @RolesAllowed({"Admin"})
    public List<MyPayPalUser> getAllUsers() {
        try {
            List<MyPayPalUser> myPayPalUsers = (List<MyPayPalUser>) entityManager.createNamedQuery("findAllUsers", MyPayPalUser.class).getResultList();
            return myPayPalUsers;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

}
