/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalTransaction;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author p-computers
 */
@Local
public interface TransactionServiceBeanLocal {
    
    public MyPayPalTransaction getTransaction(String email);
    
    public double getBalance(String email);

    public MyPayPalTransaction createTransaction(String email, double amount, String transactionType, String recipient);

    public boolean updateTransaction(MyPayPalTransaction myPayPalTransaction);

    public List<MyPayPalTransaction> getAllTransactions();
    
    public List<MyPayPalTransaction> getAllUserTransactions(String email);
    
    public List<MyPayPalTransaction> getAllUserRecentTransactions(String email);
}
