/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalUser;
import com.app.datalayer.PaymentRequest;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author p-computers
 */
@DeclareRoles({"User", "Admin"})
@Stateless
public class PaymentRequestService implements PaymentRequestServiceLocal {

    @PersistenceContext
    EntityManager entityManager;

    @EJB
    UserServiceBeanLocal userServiceBeanLocal;

    @EJB
    NotificationServiceLocal notificationServiceLocal;

    private static final Logger LOG = Logger.getLogger("TransactionServiceBean");

    @Override
    @RolesAllowed({"User", "Admin"})
    public boolean approvePaymentRequest(PaymentRequest paymentRequest) {
        try {
            paymentRequest.setRequestStatus("approved");
            updatePaymentRequest(paymentRequest);
            MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(paymentRequest.getEmail());
            String notificationMessage = paymentRequest.getSender() + " has approved your request of " + myPayPalUser.getCurrency() + " " + paymentRequest.getAmount();
            notificationServiceLocal.addNotification(paymentRequest.getEmail(), notificationMessage);
            return true;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return false;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public boolean rejectPaymentRequest(PaymentRequest paymentRequest) {
        try {
            paymentRequest.setRequestStatus("rejected");
            updatePaymentRequest(paymentRequest);
            MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(paymentRequest.getEmail());
            String notificationMessage = paymentRequest.getSender() + " has rejected your request of " + myPayPalUser.getCurrency() + " " + paymentRequest.getAmount();
            notificationServiceLocal.addNotification(paymentRequest.getEmail(), notificationMessage);
            return true;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return false;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public List<PaymentRequest> getUserPaymentRequests(String email) {
        try {
            List<PaymentRequest> results = (List<PaymentRequest>) entityManager.createNamedQuery("findUserPaymentRequests")
                    .setParameter("email", email)
                    .getResultList();
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"Admin"})
    public List<PaymentRequest> getAllPaymentRequests() {
        try {
            List<PaymentRequest> results = (List<PaymentRequest>) entityManager.createNamedQuery("findAllPaymentRequests")
                    .getResultList();
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public PaymentRequest getPaymentRequest(long id) {
        try {
            PaymentRequest paymentRequest = entityManager.find(PaymentRequest.class, id);
            return paymentRequest;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public boolean updatePaymentRequest(PaymentRequest paymentRequest) {
        try {
            entityManager.merge(paymentRequest);
            return true;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return false;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public PaymentRequest addPaymentRequest(String email, String sender, double amount, String comment) {
        try {
            PaymentRequest paymentRequest = new PaymentRequest(email, sender, amount, comment);
            entityManager.persist(paymentRequest);
            notificationServiceLocal.addNotification(email, comment + ". Please wait for the sender to confirm the request.");
            notificationServiceLocal.addNotification(sender, comment + ". Please confirm or reject this request.");
            return paymentRequest;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
