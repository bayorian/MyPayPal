/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.PaymentRequest;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author p-computers
 */
@Local
public interface PaymentRequestServiceLocal {

    public List<PaymentRequest> getUserPaymentRequests(String email);
    
    public List<PaymentRequest> getAllPaymentRequests();
    
    public PaymentRequest getPaymentRequest(long id);
    
    public boolean updatePaymentRequest(PaymentRequest paymentRequest);
    
    public boolean approvePaymentRequest(PaymentRequest paymentRequest);
    
    public boolean rejectPaymentRequest(PaymentRequest paymentRequest);

    public PaymentRequest addPaymentRequest(String email, String sender, double amount, String comment);

}
