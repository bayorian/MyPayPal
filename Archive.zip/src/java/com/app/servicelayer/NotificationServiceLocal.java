/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.Notification;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author p-computers
 */
@Local
public interface NotificationServiceLocal {

    public List<Notification> getNotifications(String email);
    
    public Notification addNotification(String email, String notificationMessage);

    public long getUnreadNotificationCount(String email);

    public void markNotificationsAsRead(String email);

}
