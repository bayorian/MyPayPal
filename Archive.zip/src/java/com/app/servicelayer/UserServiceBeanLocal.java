/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalUser;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author p-computers
 */
@Local
public interface UserServiceBeanLocal {

    public MyPayPalUser getUser(String email);

    public MyPayPalUser createUser(String email, String password, String currency, String name, String userType);

    public boolean updateUser(MyPayPalUser myPayPalUser);
    
    public boolean setUserType(String email, String userType);

    public List<MyPayPalUser> getAllUsers();

}
