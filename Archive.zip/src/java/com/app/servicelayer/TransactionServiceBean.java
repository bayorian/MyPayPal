/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalTransaction;
import com.app.datalayer.MyPayPalUser;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

/**
 *
 * @author p-computers
 */
@Stateless
@DeclareRoles({"User", "Admin"})
public class TransactionServiceBean implements TransactionServiceBeanLocal {

    @PersistenceContext
    EntityManager entityManager;

    @EJB
    UserServiceBeanLocal userServiceBeanLocal;

    @EJB
    NotificationServiceLocal notificationServiceLocal;

    private static final Logger LOG = Logger.getLogger("TransactionServiceBean");

    @Override
    @RolesAllowed({"User", "Admin"})
    public MyPayPalTransaction getTransaction(String email) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public MyPayPalTransaction createTransaction(String email, double amount, String transactionType, String recipient) {
        try {
            MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(email);
            if (myPayPalUser == null) {
                return null;
            }
            MyPayPalTransaction myPayPalTransaction = new MyPayPalTransaction(email, amount, transactionType, recipient);
            entityManager.persist(myPayPalTransaction);
            double balance = getBalance(email);
            myPayPalTransaction.setBalance(balance);
            myPayPalUser.setBalance(balance);
            String notificationMessage;
            if (transactionType.compareToIgnoreCase("credit") == 0) {
                notificationMessage = recipient + " sent you a total of " + myPayPalUser.getCurrency() + " " + amount;
            } else {
                notificationMessage = "You sent a total of " + myPayPalUser.getCurrency() + " " + amount + " to " + recipient;
            }
            notificationServiceLocal.addNotification(email, notificationMessage);
            return myPayPalTransaction;
        } catch (ConstraintViolationException e) {
            LOG.log(Level.SEVERE, "Exception: ");
            e.getConstraintViolations().forEach(err -> LOG.log(Level.SEVERE, err.toString()));
            return null;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public double getBalance(String email) {
        try {
            double credit = 0, debit = 0;
            Object totalCreditTransaction = entityManager.createNamedQuery("findTotalTransactionsByType")
                    .setParameter("email", email)
                    .setParameter("transactionType", "credit")
                    .getSingleResult();
            if (totalCreditTransaction != null) {
                credit = (Double) totalCreditTransaction;
            }
            Object totalDebitTransaction = entityManager.createNamedQuery("findTotalTransactionsByType")
                    .setParameter("email", email)
                    .setParameter("transactionType", "debit")
                    .getSingleResult();
            if (totalDebitTransaction != null) {
                debit = (Double) totalDebitTransaction;
            }
            return credit - debit;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return -1;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public boolean updateTransaction(MyPayPalTransaction myPayPalTransaction) {
        try {
            entityManager.merge(myPayPalTransaction);
            return true;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Exception: " + e.getMessage());
            return false;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public List<MyPayPalTransaction> getAllUserTransactions(String email) {
        try {
            List<MyPayPalTransaction> results = (List<MyPayPalTransaction>) entityManager.createNamedQuery("findUserTransactions")
                    .setParameter("email", email)
                    .getResultList();
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public List<MyPayPalTransaction> getAllUserRecentTransactions(String email) {
        try {
            List<MyPayPalTransaction> results = (List<MyPayPalTransaction>) entityManager.createNamedQuery("findUserTransactions")
                    .setParameter("email", email)
                    .setMaxResults(5)
                    .getResultList();
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"Admin"})
    public List<MyPayPalTransaction> getAllTransactions() {
        try {
            List<MyPayPalTransaction> results = (List<MyPayPalTransaction>) entityManager.createNamedQuery("findAllTransactions")
                    .getResultList();
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

}
