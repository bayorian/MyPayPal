/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.MyPayPalTransaction;
import com.app.datalayer.MyPayPalUser;
import com.app.weblayer.UserBean;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author p-computers
 */
@Named(value = "adminBean")
@RequestScoped
public class AdminBean {

    @EJB
    private UserServiceBeanLocal userServiceBeanLocal;
    
    @EJB
    private TransactionServiceBeanLocal transactionServiceBeanLocal;

    @Inject
    UserBean userBean;

    private String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * Creates a new instance of AdminBean
     */
    public AdminBean() {
    }

    public void setUserType(String email, String userType) {
        if (userServiceBeanLocal.setUserType(email, userType)) {
            if (email.compareToIgnoreCase(userBean.getMyPayPalUser().getEmail()) == 0 && userType.compareToIgnoreCase("User") == 0) {
                userBean.logout();
            } else {
                response = email + " User Type is now changed to " + userType;
            }
        }
    }
    
    public List<MyPayPalTransaction> getAllTransactions() {
        return transactionServiceBeanLocal.getAllTransactions();
    }

    public List<MyPayPalUser> getAllUsers() {
        return userServiceBeanLocal.getAllUsers();
    }

}
