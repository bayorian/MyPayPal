/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.servicelayer;

import com.app.datalayer.Notification;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author p-computers
 */
@Stateless
@DeclareRoles({"User", "Admin"})
public class NotificationService implements NotificationServiceLocal {

    @PersistenceContext
    EntityManager entityManager;

    private static final Logger LOG = Logger.getLogger("TransactionServiceBean");

    @Override
    @RolesAllowed({"User", "Admin"})
    public List<Notification> getNotifications(String email) {
        try {
            List<Notification> results = (List<Notification>) entityManager.createNamedQuery("findUserNotifications")
                    .setParameter("email", email)
                    .getResultList();
            this.markNotificationsAsRead(email);
            return results;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public Notification addNotification(String email, String notificationMessage) {
        try {
            Notification notification = new Notification(email, notificationMessage);
            entityManager.persist(notification);
            return notification;
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return null;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public long getUnreadNotificationCount(String email) {
        try {
            long notificationCount = 0;
            Object totalNotificationCount = entityManager.createNamedQuery("findUnreadNotificationCount")
                    .setParameter("email", email)
                    .getSingleResult();            
            if (totalNotificationCount != null) {
                notificationCount = (Long) totalNotificationCount;
            }
            return notificationCount;
        } catch (Exception ex) {            
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
            return -1;
        }
    }

    @Override
    @RolesAllowed({"User", "Admin"})
    public void markNotificationsAsRead(String email) {
        try {
            entityManager.createNamedQuery("markNotificationsAsRead")
                    .setParameter("email", email)
                    .executeUpdate();
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Exception: " + ex.getMessage());
        }
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
