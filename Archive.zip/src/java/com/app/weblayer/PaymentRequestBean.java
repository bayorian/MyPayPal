/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.weblayer;

import com.app.datalayer.MyPayPalUser;
import com.app.datalayer.PaymentRequest;
import com.app.restlayer.CurrencyConverterClient;
import com.app.servicelayer.PaymentRequestServiceLocal;
import com.app.servicelayer.TransactionServiceBeanLocal;
import com.app.servicelayer.UserServiceBeanLocal;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author p-computers
 */
@Named(value = "paymentRequestBean")
@RequestScoped
public class PaymentRequestBean {

    @EJB
    TransactionServiceBeanLocal transactionServiceBeanLocal;

    @EJB
    PaymentRequestServiceLocal paymentRequestServiceLocal;

    @EJB
    UserServiceBeanLocal userServiceBeanLocal;

    @Inject
    UserBean userBean;

    private String error;
    private String response;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * Creates a new instance of PaymentRequestBean
     */
    public PaymentRequestBean() {
    }

    public List<PaymentRequest> getPaymentRequests() {
        return paymentRequestServiceLocal.getUserPaymentRequests(userBean.getMyPayPalUser().getEmail());
    }

    public void approve(long id) {
        PaymentRequest paymentRequest = paymentRequestServiceLocal.getPaymentRequest(id);
        if (paymentRequest == null || paymentRequest.getSender().compareToIgnoreCase(userBean.getMyPayPalUser().getEmail()) != 0) {
            error = "Invalid Payment Request. Payment Request not found.";
            return;
        }
        if (paymentRequest.getRequestStatus().compareToIgnoreCase("pending") != 0) {
            error = "Invalid Payment Request. Payment Request already processed.";
            return;
        }
        MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(paymentRequest.getEmail());
        if (myPayPalUser == null) {
            error = "Recipient's Email Address cannot be found. Invalid Payment Request.";
            return;
        }
        double amount = paymentRequest.getAmount();
        CurrencyConverterClient currencyConverterClient = new CurrencyConverterClient();
        double conversion = currencyConverterClient.getConversion(myPayPalUser.getCurrency(), userBean.getMyPayPalUser().getCurrency(), String.valueOf(amount));
        if (userBean.getMyPayPalUser().getBalance() < conversion) {
            error = "You do not have sufficient balance to approve this transaction. Please fund your account and try again.";
            return;
        }
        if (paymentRequestServiceLocal.approvePaymentRequest(paymentRequest)) {
            transactionServiceBeanLocal.createTransaction(userBean.getMyPayPalUser().getEmail(), conversion, "debit", paymentRequest.getEmail());
            transactionServiceBeanLocal.createTransaction(paymentRequest.getEmail(), amount, "credit", userBean.getMyPayPalUser().getEmail());
            userBean.updateMyPayPalUser();
            response = "Payment Request Approved Successfully! A total of " + userBean.getCurrencySymbol() + conversion + " (" + myPayPalUser.getCurrency() + " " + amount + ")" + " has been sent successfully to " + paymentRequest.getEmail();
        } else {
            error = "An error occured when approving this request. Please try again.";
        }
    }

    public void reject(long id) {

    }

}
