/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.weblayer;

import com.app.datalayer.MyPayPalTransaction;
import com.app.datalayer.MyPayPalUser;
import com.app.restlayer.CurrencyConverterClient;
import com.app.servicelayer.PaymentRequestServiceLocal;
import com.app.servicelayer.TransactionServiceBeanLocal;
import com.app.servicelayer.UserServiceBeanLocal;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author p-computers
 */
@Named(value = "transactionBean")
@RequestScoped
public class TransactionBean {

    @EJB
    TransactionServiceBeanLocal transactionServiceBeanLocal;

    @EJB
    UserServiceBeanLocal userServiceBeanLocal;

    @EJB
    PaymentRequestServiceLocal paymentRequestServiceLocal;

    @Inject
    UserBean userBean;

    private String email;
    private double amount;
    private String response;
    private String error;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * Get the value of amount
     *
     * @return the value of amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Set the value of amount
     *
     * @param amount new value of amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Get the value of email
     *
     * @return the value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the value of email
     *
     * @param email new value of email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Creates a new instance of TransactionBean
     */
    public TransactionBean() {
    }

    public void getTransactions() {

    }

    public List<MyPayPalTransaction> getRecentTransactions() {
        return transactionServiceBeanLocal.getAllUserRecentTransactions(userBean.getMyPayPalUser().getEmail());
    }

    public List<MyPayPalTransaction> getUserTransactions() {
        return transactionServiceBeanLocal.getAllUserTransactions(userBean.getMyPayPalUser().getEmail());
    }       

    public String sendMoney() {
        MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(email);
        if (myPayPalUser == null) {
            error = "Recipient's Email Address cannot be found. Please enter valid email address.";
            return null;
        }
        if (email.compareToIgnoreCase(userBean.getMyPayPalUser().getEmail()) == 0) {
            error = "You cannot send money to yourself!";
            return null;
        }
        if (userBean.getMyPayPalUser().getBalance() < amount) {
            error = "You do not have sufficient balance to perform this transaction. Please fund your account and try again.";
            return null;
        }
        transactionServiceBeanLocal.createTransaction(userBean.getMyPayPalUser().getEmail(), amount, "debit", email);
        CurrencyConverterClient currencyConverterClient = new CurrencyConverterClient();
        double conversion = currencyConverterClient.getConversion(userBean.getMyPayPalUser().getCurrency(), myPayPalUser.getCurrency(), String.valueOf(amount));
        transactionServiceBeanLocal.createTransaction(email, conversion, "credit", userBean.getMyPayPalUser().getEmail());
        userBean.updateMyPayPalUser();
        response = "A total of " + userBean.getCurrencySymbol() + amount + " (" + myPayPalUser.getCurrency() + " " + conversion + ")" + " has been sent successfully to " + email;
        return null;
    }

    public String requestMoney() {
        MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(email);
        if (myPayPalUser == null) {
            error = "Sender's Email Address cannot be found. Please enter valid email address.";
            return null;
        }
        if (email.compareToIgnoreCase(userBean.getMyPayPalUser().getEmail()) == 0) {
            error = "You cannot request money from yourself!";
            return null;
        }
        CurrencyConverterClient currencyConverterClient = new CurrencyConverterClient();
        double conversion = currencyConverterClient.getConversion(userBean.getMyPayPalUser().getCurrency(), myPayPalUser.getCurrency(), String.valueOf(amount));
        if (myPayPalUser.getBalance() < conversion) {
            error = "The sender does not have sufficient balance to approve this transaction. Please contact the sender to fund account and try again.";
            return null;
        }
        String comment = userBean.getMyPayPalUser().getEmail() + " requested a total of " + userBean.getCurrencySymbol() + amount + " (" + myPayPalUser.getCurrency() + " " + conversion + ")" + " from " + email;
        paymentRequestServiceLocal.addPaymentRequest(userBean.getMyPayPalUser().getEmail(), email, amount, comment);
        response = comment + ". Please wait for confirmation from the sender.";
        return null;
    }

}
