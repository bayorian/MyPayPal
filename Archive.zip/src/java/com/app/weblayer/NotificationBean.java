/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.weblayer;

import com.app.datalayer.Notification;
import com.app.servicelayer.NotificationServiceLocal;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author p-computers
 */
@Named(value = "notificationBean")
@RequestScoped
public class NotificationBean {

    @Inject
    UserBean userBean;

    @EJB
    NotificationServiceLocal notificationService;

    /**
     * Get the value of notificationCount
     *
     * @return the value of notificationCount
     */
    public long getNotificationCount() {
        return notificationService.getUnreadNotificationCount(userBean.getMyPayPalUser().getEmail());

    }

    public List<Notification> getNotifications() {
        return notificationService.getNotifications(userBean.getMyPayPalUser().getEmail());
    }

    /**
     * Creates a new instance of NotificationBean
     */
    public NotificationBean() {
    }

}
