/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.weblayer;

import com.app.datalayer.MyPayPalUser;
import com.app.servicelayer.UserServiceBeanLocal;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author p-computers
 */
@Named(value = "userBean")
@SessionScoped
public class UserBean implements Serializable {

    private MyPayPalUser myPayPalUser;
    private final HashMap<String, String> currencyMap;
    @EJB
    private UserServiceBeanLocal userServiceBeanLocal;
    private static final Logger LOG = Logger.getLogger("UserBean");

    /**
     * Get the value of myPayPalUser
     *
     * @return the value of myPayPalUser
     */
    public MyPayPalUser getMyPayPalUser() {
        return myPayPalUser;
    }

    public void setMyPayPalUser(MyPayPalUser myPayPalUser) {
        this.myPayPalUser = myPayPalUser;
    }

    /**
     * Set the value of myPayPalUser
     *
     */
    public void updateMyPayPalUser() {
        MyPayPalUser myPayPalUserNew = userServiceBeanLocal.getUser(myPayPalUser.getEmail());
        setMyPayPalUser(myPayPalUserNew);
    }

    public String getCurrencySymbol() {
        return currencyMap.get(myPayPalUser.getCurrency());
    }

    public String getUserCurrencySymbol(String currency) {
        return currencyMap.get(currency);
    }    

    /**
     * Creates a new instance of User
     */
    public UserBean() {
        currencyMap = new HashMap<>();
        currencyMap.put("GBP", "£");
        currencyMap.put("USD", "$");
        currencyMap.put("EUR", "€");
    }

    @PostConstruct
    public void init() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        String sessionEmail = request.getUserPrincipal().toString();
        myPayPalUser = userServiceBeanLocal.getUser(sessionEmail);
    }

    public void logout() {
        try {
            FacesContext context = FacesContext.getCurrentInstance();
            HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
            request.logout();
            context.getExternalContext().invalidateSession();
            context.getExternalContext().redirect("../index.xhtml");
        } catch (ServletException | IOException ex) {
            LOG.log(Level.SEVERE, ex.getMessage());
        }
    }

}
