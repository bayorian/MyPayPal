/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.weblayer;

import com.app.datalayer.MyPayPalUser;
import com.app.restlayer.CurrencyConverterClient;
import com.app.servicelayer.TransactionServiceBeanLocal;
import com.app.servicelayer.UserServiceBeanLocal;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.ClientErrorException;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author p-computers
 */
@Named(value = "registerBean")
@RequestScoped
public class RegisterBean {

    private String password;
    private String name;
    private String email;
    private String confirmPassword;
    private String userType;
    private String currency;
    private String error;
    private String success;

    public static final int USER_STARTING_AMOUNT = 1000;

    @EJB
    private UserServiceBeanLocal userServiceBeanLocal;

    @EJB
    private TransactionServiceBeanLocal transactionServiceBeanLocal;

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }    
    
    /**
     * Get the value of success
     *
     * @return the value of success
     */
    public String getSuccess() {
        return success;
    }

    /**
     * Set the value of success
     *
     * @param success new value of success
     */
    public void setSuccess(String success) {
        this.success = success;
    }

    /**
     * Get the value of error
     *
     * @return the value of error
     */
    public String getError() {
        return error;
    }

    /**
     * Set the value of error
     *
     * @param error new value of error
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * Get the value of currency
     *
     * @return the value of currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the value of currency
     *
     * @param currency new value of currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Get the value of confirmPassword
     *
     * @return the value of confirmPassword
     */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * Set the value of confirmPassword
     *
     * @param confirmPassword new value of confirmPassword
     */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /**
     * Get the value of email
     *
     * @return the value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the value of email
     *
     * @param email new value of email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get the value of password
     *
     * @return the value of password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Set the value of password
     *
     * @param password new value of password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Creates a new instance of RegisterBean
     */
    public RegisterBean() {
    }

    public void validateConfirmPassword(FacesContext context, UIComponent toValidate, Object value) {
        UIInput passwordComponent = (UIInput) toValidate.getAttributes().get("password");
        String password_text = (String) passwordComponent.getValue();
        if (password_text.compareTo(value.toString()) != 0) {
            ((UIInput) toValidate).setValid(false);
            FacesMessage message = new FacesMessage("Confirm Password must be the same with Password");
            context.addMessage(toValidate.getClientId(context), message);
        }
    }

    public void register() {
        try {
            MyPayPalUser myPayPalUser = userServiceBeanLocal.getUser(email);
            if (myPayPalUser != null) {
                error = "Email Address already exists. Please Use another email address.";
            } else {
                userServiceBeanLocal.createUser(email, sha256(password), currency, name, userType);
                FacesContext context = FacesContext.getCurrentInstance();
                HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
                request.login(email, password);
                CurrencyConverterClient currencyConverterClient = new CurrencyConverterClient();
                double conversion = currencyConverterClient.getConversion("GBP", currency, String.valueOf(USER_STARTING_AMOUNT));
                transactionServiceBeanLocal.createTransaction(email, conversion, "credit", "Admin");
                context.getExternalContext().redirect("./user");
            }
        } catch (IOException | ServletException | ClientErrorException ex) {
            Logger.getLogger("RegisterBean").log(Level.SEVERE, ex.getMessage());
        }
    }

    private String sha256(String passwordToHash) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(passwordToHash.getBytes("UTF-8"));
            return DatatypeConverter.printHexBinary(hash).toLowerCase();
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            return null;
        }
    }

}
