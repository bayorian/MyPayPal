/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.datalayer;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 *
 * @author p-computers
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "findUnreadNotificationCount", query = "SELECT COUNT(n.id) FROM Notification n WHERE n.notificationRead = false AND n.email = :email")
    , 
    @NamedQuery(name = "findUserNotifications", query = "SELECT n FROM Notification n WHERE n.email = :email ORDER BY n.dateCreated DESC")
    ,
    @NamedQuery(name = "findAllNotifications", query = "SELECT n FROM Notification n ORDER BY n.dateCreated DESC")
    ,
    @NamedQuery(name = "markNotificationsAsRead", query = "UPDATE Notification n SET n.notificationRead = true WHERE n.email = :email")
})
public class Notification implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotNull
    @Pattern(regexp = "[\\w\\.-]*[a-zA-Z0-9_]@[\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]")
    private String email;
    @NotNull
    private String notificationMessage;
    @NotNull
    private boolean notificationRead;
    @NotNull
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dateCreated;

    public Notification(String email, String notificationMessage) {
        this.email = email;
        this.notificationMessage = notificationMessage;
        this.notificationRead = false;
        this.dateCreated = new Date();
    }

    public Notification() {
    }

    /**
     * Get the value of dateCreated
     *
     * @return the value of dateCreated
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * Set the value of dateCreated
     *
     * @param dateCreated new value of dateCreated
     */
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * Get the value of notificationRead
     *
     * @return the value of notificationRead
     */
    public boolean getNotificationRead() {
        return notificationRead;
    }

    /**
     * Set the value of notificationRead
     *
     * @param notificationRead new value of notificationRead
     */
    public void setNotificationRead(boolean notificationRead) {
        this.notificationRead = notificationRead;
    }

    /**
     * Get the value of notificationMessage
     *
     * @return the value of notificationMessage
     */
    public String getNotificationMessage() {
        return notificationMessage;
    }

    /**
     * Set the value of notificationMessage
     *
     * @param notificationMessage new value of notificationMessage
     */
    public void setNotificationMessage(String notificationMessage) {
        this.notificationMessage = notificationMessage;
    }

    /**
     * Get the value of email
     *
     * @return the value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the value of email
     *
     * @param email new value of email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Notification)) {
            return false;
        }
        Notification other = (Notification) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.app.datalayer.Notification[ id=" + id + " ]";
    }

}
