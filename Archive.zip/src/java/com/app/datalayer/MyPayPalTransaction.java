/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.datalayer;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 *
 * @author p-computers
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "findTotalTransactionsByType", query = "SELECT SUM(t.amount) FROM MyPayPalTransaction t WHERE t.transactionType = :transactionType AND t.email = :email")
    , 
    @NamedQuery(name = "findUserTransactions", query = "SELECT t FROM MyPayPalTransaction t WHERE t.email = :email ORDER BY t.dateCreated DESC")
    ,
    @NamedQuery(name = "findAllTransactions", query = "SELECT t FROM MyPayPalTransaction t ORDER BY t.dateCreated DESC")
})
public class MyPayPalTransaction implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotNull
    @Pattern(regexp = "[\\w\\.-]*[a-zA-Z0-9_]@[\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]")
    private String email;
    @NotNull
    private double amount;
    @NotNull
    private String transactionType;
    @NotNull
    private String comment;
    @NotNull
    private double balance;
    @NotNull
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dateCreated;

    public MyPayPalTransaction(String email, double amount, String transactionType, String recipient) {
        this.email = email;
        this.amount = amount;
        this.transactionType = transactionType;
        this.comment = transactionType.compareToIgnoreCase("credit") == 0 ? "Sender: " + recipient : "Recipient: " + recipient;
        this.balance = 0;
        this.dateCreated = new Date();
    }

    public MyPayPalTransaction() {
    }

    /**
     * Get the value of dateCreated
     *
     * @return the value of dateCreated
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * Set the value of dateCreated
     *
     * @param dateCreated new value of dateCreated
     */
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * Get the value of balance
     *
     * @return the value of balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Set the value of balance
     *
     * @param balance new value of balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Get the value of comment
     *
     * @return the value of comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Set the value of comment
     *
     * @param comment new value of comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * Get the value of transactionType
     *
     * @return the value of transactionType
     */
    public String getTransactionType() {
        return transactionType;
    }

    /**
     * Set the value of transactionType
     *
     * @param transactionType new value of transactionType
     */
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * Get the value of amount
     *
     * @return the value of amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Set the value of amount
     *
     * @param amount new value of amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Get the value of email
     *
     * @return the value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the value of email
     *
     * @param email new value of email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MyPayPalTransaction)) {
            return false;
        }
        MyPayPalTransaction other = (MyPayPalTransaction) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.app.datalayer.Transaction[ id=" + id + " ]";
    }

}
