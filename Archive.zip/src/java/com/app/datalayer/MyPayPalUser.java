/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.datalayer;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 *
 * @author p-computers
 */
@Entity
@NamedQuery(name = "findAllUsers", query = "SELECT u FROM MyPayPalUser u ORDER BY u.dateCreated")
public class MyPayPalUser implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Pattern(regexp = "[\\w\\.-]*[a-zA-Z0-9_]@[\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]")
    private String email;
    @NotNull
    @Size(min = 3, max = 50)
    private String name;
    @NotNull
    @Size(min = 6, max = 100)
    private String password;
    @NotNull
    private String currency;    
    @NotNull
    private double balance;
    @NotNull
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dateCreated;
    @NotNull
    private String userType;

    /**
     * Get the value of userType
     *
     * @return the value of userType
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Set the value of userType
     *
     * @param userType new value of userType
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }


    public MyPayPalUser() {
    }

    public MyPayPalUser(String name, String password, String email, String currency, String userType) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.currency = currency;
        this.balance = 0;
        this.dateCreated = new Date(); 
        this.userType = userType;
    }

    /**
     * Get the value of dateCreated
     *
     * @return the value of dateCreated
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * Set the value of dateCreated
     *
     * @param dateCreated new value of dateCreated
     */
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * Get the value of balance
     *
     * @return the value of balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Set the value of balance
     *
     * @param balance new value of balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Get the value of currency
     *
     * @return the value of currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the value of currency
     *
     * @param currency new value of currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Get the value of email
     *
     * @return the value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the value of email
     *
     * @param email new value of email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Get the value of password
     *
     * @return the value of password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Set the value of password
     *
     * @param password new value of password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (email != null ? email.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the email fields are not set
        if (!(object instanceof MyPayPalUser)) {
            return false;
        }
        MyPayPalUser other = (MyPayPalUser) object;
        if ((this.email == null && other.email != null) || (this.email != null && !this.email.equals(other.email))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.app.datalayer.User[ email=" + email + " ]";
    }

}
