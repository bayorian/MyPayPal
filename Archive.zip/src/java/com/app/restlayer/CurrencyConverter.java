/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.restlayer;

import java.util.HashMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author p-computers
 */
@Path("conversion")
public class CurrencyConverter {

    @Context
    private UriInfo context;
    private final HashMap<String, Double> currencyMap;

    /**
     * Creates a new instance of CurrencyConverter
     */
    public CurrencyConverter() {
        currencyMap = new HashMap<>();
        currencyMap.put("GBP-USD", 1.39);
        currencyMap.put("GBP-EUR", 1.18);
        currencyMap.put("USD-GBP", 0.72);
        currencyMap.put("EUR-GBP", 0.85);
        currencyMap.put("USD-EUR", 0.85);
        currencyMap.put("EUR-USD", 1.17);
    }

    /**
     * Retrieves representation of an instance of
     * com.app.restlayer.CurrencyConverter
     *
     * @param currency1
     * @param currency2
     * @param amount
     * @return an instance of java.lang.String
     */
    @GET
    @Path("{currency1}/{currency2}/{amount}/")
    @Produces(MediaType.APPLICATION_JSON)
    public String getConversion(@PathParam("currency1") String currency1, @PathParam("currency2") String currency2, @PathParam("amount") double amount) {
        double conversion;
        if (currency1.compareToIgnoreCase(currency2) == 0) {
            conversion = amount;
        } else {
            double conversionConstant = currencyMap.get(currency1 + "-" + currency2);
            conversion = conversionConstant * amount;
        }
        JsonObject model = Json.createObjectBuilder()
                .add("currency1", currency1)
                .add("currency2", currency2)
                .add("amount", amount)
                .add("conversion", String.format("%.2f", conversion))
                .build();
        return model.toString();
    }

    /**
     * PUT method for updating or creating an instance of CurrencyConverter
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putConversion(String content) {
    }
}
